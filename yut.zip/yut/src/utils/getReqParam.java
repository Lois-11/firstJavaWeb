package utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;

public class getReqParam {
	
    public static Map<String, String> getParams(HttpServletRequest req) throws IOException {
        // ��ȡ���в���
    	ServletInputStream is = (ServletInputStream) req.getInputStream();
    	BufferedReader br = new BufferedReader(new InputStreamReader(is, "utf-8"));
    	StringBuffer sb = new StringBuffer("");
    	String temp;
    	while ((temp = br.readLine()) != null) { 
    	  sb.append(temp);
    	}
    	br.close();
    	String params = sb.toString();
    	String paramss =  params.toString().replace("\"", "").replace("{", "").replace("}", "");
        // �ַ����ָ�
        String[] param =  paramss.split(",");
        List<String> paramKey = new ArrayList<String>();
        List<String> paramValue =  new ArrayList<String>();
        Map<String, String> result = new HashMap<String, String>();
        for(int i=0;i<param.length;i++) {
        	paramKey.add(param[i].split(":")[0]);
        	paramValue.add(param[i].split(":")[1]);
        	result.put(paramKey.get(i), paramValue.get(i));
        }
        return result;
    }

}
