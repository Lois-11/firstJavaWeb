package utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;


public class c3p0utils {
		 
		   private static DataSource ds = new ComboPooledDataSource("helloc3p0");

		   
		   public static DataSource getDataSource() {
			   return ds;
		   }
		   
		   //��ȡConnection����
		   public static  Connection getConnection() throws SQLException{
			    return ds.getConnection();
			}
		 
		   //�ر�Connection����
		   public static void closeAll(Connection conn, Statement st ,ResultSet rs) {
		      if(rs != null) {
		    	  try {
		    		  rs.close();
		    	  } catch (SQLException e) {
		    		  e.printStackTrace();
		    	  }
		    	  rs = null;
		      }
		      if(st != null) {
		    	  try {
		    		  st.close();
		    	  } catch (SQLException e) {
		    		  e.printStackTrace();
		    	  }
		    	  st = null;
		      }
		      if(conn != null) {
		    	  try {
		    		  conn.close();
		    	  } catch (SQLException e) {
		    		  e.printStackTrace();
		    	  }
		    	  conn = null;
		      }
		   }

}