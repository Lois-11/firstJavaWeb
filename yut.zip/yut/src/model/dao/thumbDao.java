package model.dao;

import org.apache.commons.dbutils.*;

import model.da.Story;
import model.da.Thumb;
import model.da.User;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import sqlCon.sqlConn;
import utils.c3p0utils;

public class thumbDao {
	
	private static Connection conn = sqlConn.getConnection();
	
	public static List<Thumb> query() throws SQLException {
		// TODO Auto-generated method stub
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("select user_id, story_id, status from thumb");
		List<Thumb> thList = new ArrayList<Thumb>();
		Thumb th = null;
		// ��������������ݣ��ͻ�ѭ����ӡ����
		while (rs.next()) {
			th = new Thumb();
			th.setUser_id(rs.getInt("user_id"));
			th.setStory_id(rs.getInt("story_id"));
			th.setStatus(rs.getInt("status"));
			thList.add(th);
		}
		return thList;
	}
	
	public void newThumb(String story_name, String tel) throws SQLException {
		int user_id = 0;
		userDao ud = new userDao();
		List<User> userList = null;
		try {
			userList = ud.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (User user : userList) {
			if (user.getTel().equals(tel)) {
				user_id = user.getID();
			}
		}
		int story_id = 0;
		storyDao sd = new storyDao();
		List<Story> strList = null;
		try {
			strList = sd.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (Story str : strList) {
			if (str.getStory_name().equals(story_name)) {
				story_id = str.getStory_id();
			}
		}
		Thumb th = new Thumb(story_id, user_id, 0);
		QueryRunner qr=new QueryRunner(c3p0utils.getDataSource());
		String sql = "insert into thumb(user_id, story_id, status) values("
				+ "?,?,0)";
		List<Object> list=new ArrayList<Object>();
		list.add(th.getUser_id());
		list.add(th.getStory_id());
		qr.update(sql,list.toArray());
	}
	
	public static void addThumb(String story_name, String tel) throws SQLException {
		int user_id = 0;
		userDao ud = new userDao();
		List<User> userList = null;
		try {
			userList = ud.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (User user : userList) {
			if (user.getTel().equals(tel)) {
				user_id = user.getID();
			}
		}
		int story_id = 0;
		storyDao sd = new storyDao();
		List<Story> strList = null;
		try {
			strList = sd.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (Story str : strList) {
			if (str.getStory_name().equals(story_name)) {
				story_id = str.getStory_id();
			}
		}
		Thumb th = new Thumb(story_id, user_id, 1);
		QueryRunner qr=new QueryRunner(c3p0utils.getDataSource());
		String sql = "update thumb set status=1 where user_id=? and story_id=?";
		List<Object> list=new ArrayList<Object>();
		list.add(th.getUser_id());
		list.add(th.getStory_id());
		qr.update(sql,list.toArray());
	}
	
	public static void delThumb(String story_name, String tel) throws SQLException {
		int user_id = 0;
		userDao ud = new userDao();
		List<User> userList = null;
		try {
			userList = ud.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (User user : userList) {
			if (user.getTel().equals(tel)) {
				user_id = user.getID();
			}
		}
		int story_id = 0;
		storyDao sd = new storyDao();
		List<Story> strList = null;
		try {
			strList = sd.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (Story str : strList) {
			if (str.getStory_name().equals(story_name)) {
				story_id = str.getStory_id();
			}
		}
		Thumb th = new Thumb(story_id, user_id, 0);
		QueryRunner qr=new QueryRunner(c3p0utils.getDataSource());
		String sql = "update thumb set status=0 where user_id=? and story_id=?";
		List<Object> list=new ArrayList<Object>();
		list.add(th.getUser_id());
		list.add(th.getStory_id());
		qr.update(sql,list.toArray());
	}
	
	public static boolean isthumb(String story_name, String tel) throws SQLException {
		int user_id = 0;
		userDao ud = new userDao();
		List<User> userList = null;
		try {
			userList = ud.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (User user : userList) {
			if (user.getTel().equals(tel)) {
				user_id = user.getID();
			}
		}
		int story_id = 0;
		storyDao sd = new storyDao();
		List<Story> strList = null;
		try {
			strList = sd.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (Story str : strList) {
			if (str.getStory_name().equals(story_name)) {
				story_id = str.getStory_id();
			}
		}
		int status = 0;
		List<Thumb> thList = null;
		try {
			thList = thumbDao.query();
			for(Thumb th : thList) {
				if(th.getStory_id() == story_id && th.getUser_id() == user_id) {
					status = th.getStatus();
					break;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(status == 1)
			return true;
		return false;
	}
	
	public static void main(String[] args) throws SQLException {
		System.out.println(isthumb("����1","13708011111"));
	}

}