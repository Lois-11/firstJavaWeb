package model.dao;

import org.apache.commons.dbutils.*;

import model.da.Story;
import model.da.User;
import model.da.userCreRole;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import sqlCon.sqlConn;
import utils.c3p0utils;

public class userCreRoleDao {
	
	private static Connection conn = sqlConn.getConnection();
	
	public static List<userCreRole> query() throws Exception {
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("select user_id, role_id, story_id from userCreRole");
		List<userCreRole> ucrList = new ArrayList<userCreRole>();
		userCreRole ucr = null;
		// ��������������ݣ��ͻ�ѭ����ӡ����
		while (rs.next()) {
			ucr = new userCreRole();
			ucr.setUser_id(rs.getInt("user_id"));
			ucr.setRole_id(rs.getInt("role_id"));
			ucr.setStory_id(rs.getInt("story_id"));
			ucrList.add(ucr);
		}
		return ucrList;
	}
	
	public static void addCre(String story_name, String tel, int role_id) throws SQLException {
		int user_id = 0;
		userDao ud = new userDao();
		List<User> userList = null;
		try {
			userList = ud.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (User user : userList) {
			if (user.getTel().equals(tel)) {
				user_id = user.getID();
			}
		}
		int story_id = 0;
		storyDao sd = new storyDao();
		List<Story> strList = null;
		try {
			strList = sd.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (Story str : strList) {
			if (str.getStory_name().equals(story_name)) {
				story_id = str.getStory_id();
			}
		}
		userCreRole ucr = new userCreRole(story_id, user_id, role_id);
		QueryRunner qr=new QueryRunner(c3p0utils.getDataSource());
		String sql = "insert into userCreRole(user_id, role_id, story_id) values("
				+ "?,?,?)";
		List<Object> list=new ArrayList<Object>();
		list.add(ucr.getUser_id());
		list.add(ucr.getRole_id());
		list.add(ucr.getStory_id());
		qr.update(sql,list.toArray());
	}
	
	@SuppressWarnings("null")
	public static List<String> queryUserStory(String tel) throws SQLException {
		List<String> mystorys = new ArrayList<String>();

		int user_id = 0;
		userDao ud = new userDao();
		List<User> userList = null;
		try {
			userList = ud.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (User user : userList) {
			if (user.getTel().equals(tel)) {
				user_id = user.getID();
			}
		}
		
		userCreRoleDao ucrd = new userCreRoleDao();
		List<userCreRole> ucrList = null;
		try {
			ucrList = ucrd.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (userCreRole ucr : ucrList) {
			if (ucr.getUser_id() == user_id) {
				/**
				 * user_idתstory_id
				 */
				int story_id = ucr.getStory_id();
				storyDao sd = new storyDao();
				List<Story> strList = null;
				try {
					strList = sd.query();
				} catch (Exception e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				for (Story str : strList) {
					if (str.getStory_id() == story_id) {
						/**
						 * story_idתstory_name���ӵ�mystorys[]
						 */
						mystorys.add(str.getStory_name());
					}
				}
			}
		}
		return mystorys;
	}
	
	public static void main(String[] args) throws SQLException {
		List<String> result = queryUserStory("13708011111");
		for(String str:result)
			System.out.println(str);
	}

}
