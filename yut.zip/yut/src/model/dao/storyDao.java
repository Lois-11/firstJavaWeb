package model.dao;

import org.apache.commons.dbutils.*;

import model.da.Story;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import sqlCon.sqlConn;
import utils.c3p0utils;

public class storyDao {
	
	private static Connection conn = sqlConn.getConnection();
	
	
	public static List<Story> query() throws SQLException {
		// TODO Auto-generated method stub
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("select story_id, story_name, story_setting, max_role_num, now_role_num, thumb_num from story");
		List<Story> strList = new ArrayList<Story>();
		Story str = null;
		// ��������������ݣ��ͻ�ѭ����ӡ����
		while (rs.next()) {
			str = new Story();
			str.setStory_id(rs.getInt("story_id"));
			str.setStory_name(rs.getString("story_name"));
			str.setStory_setting(rs.getString("story_setting"));
			str.setMax_role_num(rs.getInt("max_role_num"));
			str.setNow_role_num(rs.getInt("now_role_num"));
			str.setThumb_num(rs.getInt("thumb_num"));
			strList.add(str);
		}
		return strList;
	}
	
	public static void addStory(String story_name, String story_setting, int max_role_num, int now_role_num) throws SQLException {
		Story sty = new Story(story_name, story_setting, max_role_num, now_role_num, 0);
		QueryRunner qr=new QueryRunner(c3p0utils.getDataSource());
		String sql = "insert into story(story_name, story_setting, max_role_num, now_role_num, thumb_num) values("
				+ "?,?,?,?,0)";
		List<Object> list=new ArrayList<Object>();
		list.add(sty.getStory_name());
		list.add(sty.getStory_setting());
		list.add(sty.getMax_role_num());
		list.add(sty.getNow_role_num());
		list.add(sty.getThumb_num());
		qr.update(sql,list.toArray());
	}
	
	public static String getStorySetting(String story_name) throws SQLException {
		String story_setting = null;
		List<Story> strList = null;
		try {
			strList = storyDao.query();
			for(Story str : strList) {
				if(str.getStory_name().equals(story_name)) {
					story_setting = str.getStory_setting();
					break;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return story_setting;
	}
	
	public static int getMaxRoleNum(String story_name) throws SQLException {
		int max_role_num = 0;
		List<Story> strList = null;
		try {
			strList = storyDao.query();
			for(Story str : strList) {
				if(str.getStory_name().equals(story_name)) {
					max_role_num = str.getMax_role_num();
					break;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return max_role_num;
	}
	
	public static int getNowRoleNum(String story_name) throws SQLException {
		int now_role_num = 0;
		List<Story> strList = null;
		try {
			strList = storyDao.query();
			for(Story str : strList) {
				if(str.getStory_name().equals(story_name)) {
					now_role_num = str.getNow_role_num();
					break;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return now_role_num;
	}
	
	public static int getThumbNum(String story_name) throws SQLException {
		int thumb_num = 0;
		List<Story> strList = null;
		try {
			strList = storyDao.query();
			for(Story str : strList) {
				if(str.getStory_name().equals(story_name)) {
					thumb_num = str.getThumb_num();
					break;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return thumb_num;
	}

	public static void main(String[] args) throws SQLException {
		System.out.println(getThumbNum("����1"));
	}

}