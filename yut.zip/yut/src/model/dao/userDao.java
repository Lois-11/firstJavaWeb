package model.dao;

import org.apache.commons.dbutils.*;

import model.da.User;
import model.da.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import sqlCon.sqlConn;
import utils.c3p0utils;

public class userDao {

	public static Connection conn = sqlConn.getConnection();

	public static List<User> query() throws Exception {
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("select user_id, username, password, gender, tel, registDate from user");
		List<User> usList = new ArrayList<User>();
		User us = null;
		// ��������������ݣ��ͻ�ѭ����ӡ����
		while (rs.next()) {
			us = new User();
			us.setID(rs.getInt("user_id"));
			us.setUsername(rs.getString("username"));
			us.setPassword(rs.getString("password"));
			us.setGender(rs.getString("gender"));
			us.setTel(rs.getString("tel"));
			us.setRegistDate(rs.getDate("registDate"));
			usList.add(us);
		}
		return usList;
	}
	
	public static String queryUserName(String tel) throws SQLException {
		String username = null;
		List<User> userList = null;
		try {
			userList = userDao.query();
			for(User user : userList) {
				if(user.getTel().equals(tel)) {
					username = user.getUsername();
					break;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return username;
	}
	
	public static String queryGender(String tel) throws SQLException {
		String gender = null;
		List<User> userList = null;
		try {
			userList = userDao.query();
			for(User user : userList) {
				if(user.getTel().equals(tel)) {
					gender = user.getGender();
					break;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return gender;
	}

	public static void registerUser(String username, String gender, String tel, String password) throws SQLException, ParseException {
		User user = new User(username, password, gender, tel, new Date());
		QueryRunner qr = new QueryRunner(c3p0utils.getDataSource());
		String sql = "insert into user(username, password, gender, tel, registDate) values(" + "?,?,?,?,?)";
		List<Object> list = new ArrayList<Object>();
		list.add(user.getUsername());
		list.add(user.getPassword());
		list.add(user.getGender());
		list.add(user.getTel());
		list.add(user.getRegistDate());
		qr.update(sql, list.toArray());
	}
	
	public static void deleteUser(String tel) throws SQLException, ParseException {
		QueryRunner qr = new QueryRunner(c3p0utils.getDataSource());
		String sql = "delete from user where tel=?;";
		List<Object> list = new ArrayList<Object>();
		list.add(tel);
		qr.update(sql, list.toArray());
	}

	public static void updateTel(String new_tel, String tel) throws SQLException {
		Connection conn = sqlConn.getConnection();
		String sql = "update user set tel=? where tel=?";
		PreparedStatement ps = conn.prepareStatement(sql);
		userDao ud = new userDao();
		List<User> usList = null;
		try {
			usList = ud.query();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String old_tel = null;
		for (User us : usList) {
			if (us.getTel() == tel) {
				old_tel = us.getTel();
			}
		}
		ps.setString(1, new_tel);
		ps.setString(2, old_tel);
		ps.execute();
	}
	
	public static String getusername(String tel, String password) {
		userDao ud = new userDao();
		String name = null;
		List<User> userList = null;
		try {
			userList = ud.query();
			for (User user : userList) {
				if (user.getTel().equals(tel) && user.getPassword().equals(password)) {
					 name = user.getUsername();
				}
			}
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		return name;
	}

	public static boolean checkUser(String tel, String password) {
		if (tel.length() == 0 || password.length() == 0)
			return false;
		userDao ud = new userDao();
		List<User> userList = null;
		try {
			userList = ud.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		boolean[] flag = new boolean[userList.size()];
		for (int i = 0; i < userList.size(); i++) {
			flag[i] = false;
		}
		for (int i = 0; i < userList.size(); i++) {
			User user = userList.get(i);
			if (user.getTel().equals(tel) && user.getPassword().equals(password)) {
				flag[i] = true;
			}
		}
		int k;
		for (k = 0; k < userList.size(); k++) {
			if (flag[k] == true)
				break;
		}
		if (k == userList.size()) {
			return false;
		} else {
			for (User user : userList) {
				if (user.getTel().equals(tel) && user.getPassword().equals(password)) {
					return true;
				}
			}
		}
		return false; 
	}
	
	public static void main(String[] args) throws SQLException {
		System.out.println(checkUser("13708011111","123456"));
	}

}