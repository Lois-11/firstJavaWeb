package model.dao;

import org.apache.commons.dbutils.*;

import model.da.Story;
import model.da.Talk;
import model.da.User;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import sqlCon.sqlConn;
import utils.c3p0utils;

public class talkDao {
	
	private static Connection conn = sqlConn.getConnection();
	
	public static List<Talk> query() throws Exception {
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("select talk_id, content, role_id, user_id, story_id from talk order by talk_id");
		List<Talk> talList = new ArrayList<Talk>();
		Talk tal = null;
		// ��������������ݣ��ͻ�ѭ����ӡ����
		while (rs.next()) {
			tal = new Talk();
			tal.setTalk_id(rs.getInt("talk_id"));
			tal.setContent(rs.getString("content"));
			tal.setRole_id(rs.getInt("role_id"));
			tal.setUser_id(rs.getInt("user_id"));
			tal.setStory_id(rs.getInt("story_id"));
			talList.add(tal);
		}
		return talList;
	}
	
	public static void addTalk(String content, int role_id, String tel, String story_name) throws SQLException {
		int user_id = 0;
		userDao ud = new userDao();
		List<User> userList = null;
		try {
			userList = ud.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (User user : userList) {
			if (user.getTel().equals(tel)) {
				user_id = user.getID();
			}
		}
		int story_id = 0;
		storyDao sd = new storyDao();
		List<Story> strList = null;
		try {
			strList = sd.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (Story str : strList) {
			if (str.getStory_name().equals(story_name)) {
				story_id = str.getStory_id();
			}
		}
		Talk tal = new Talk(content, role_id, user_id, story_id);
		QueryRunner qr=new QueryRunner(c3p0utils.getDataSource());
		String sql = "insert into talk(content, role_id, user_id, story_id) values("
				+ "?,?,?,?)";
		List<Object> list=new ArrayList<Object>();
		list.add(tal.getContent());
		list.add(tal.getRole_id());
		list.add(tal.getUser_id());
		list.add(tal.getStory_id());
		qr.update(sql,list.toArray());
	}
	
	/*
	 * ��ȡstory_id������role_id�Ľ�ɫ��������������
	 */
	public static Map<Integer,String> getContents(String story_name, int role_id) throws SQLException {
		int story_id = 0;
		storyDao sd = new storyDao();
		List<Story> strList = null;
		try {
			strList = sd.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (Story str : strList) {
			if (str.getStory_name().equals(story_name)) {
				story_id = str.getStory_id();
			}
		}
		Map<Integer,String> contents = new HashMap<Integer,String>();
		List<Talk> talList = null;
		try {
			talList = talkDao.query();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int i=1;
		for(Talk tal : talList) {
			if(tal.getStory_id()==story_id && tal.getRole_id()==role_id) {
				contents.put(i++, tal.getContent());
			}
		}
		return contents;
		
	}
	
	/*
	 * ��ȡstory_id������role_id�Ľ�ɫ�ĵ�talk_key_id����������(�ӵ�1����ʼ����)
	 */
	public static String getcontent(String story_name, int role_id, int talk_key_id) throws SQLException {
		int story_id = 0;
		storyDao sd = new storyDao();
		List<Story> strList = null;
		try {
			strList = sd.query();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (Story str : strList) {
			if (str.getStory_name().equals(story_name)) {
				story_id = str.getStory_id();
			}
		}
		String content = getContents(story_name, role_id).get(talk_key_id);
		return content;
	}
	
	public static void main(String[] args) throws SQLException {
		System.out.println(getcontent("����1",2,2));
	}

}
