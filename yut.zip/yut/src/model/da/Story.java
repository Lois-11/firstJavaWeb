package model.da;

public class Story {
	
	private int story_id;
	private String story_name;
	private String story_setting;
	private int max_role_num;
	private int now_role_num;
	private int thumb_num;
	
	public Story() {
		super();
	}
	public Story(String story_name, String story_setting, int max_role_num, int now_role_num, int thumb_num) {
		this.story_name = story_name;
		this.story_setting = story_setting;
		this.max_role_num = max_role_num;
		this.now_role_num = now_role_num;
		this.thumb_num = thumb_num;
	}
	
	public int getStory_id() {
		return story_id;
	}
	public void setStory_id(int story_id) {
		this.story_id = story_id;
	}
	public String getStory_name() {
		return story_name;
	}
	public void setStory_name(String story_name) {
		this.story_name = story_name;
	}
	public String getStory_setting() {
		return story_setting;
	}
	public void setStory_setting(String story_setting) {
		this.story_setting = story_setting;
	}
	public int getMax_role_num() {
		return max_role_num;
	}
	public void setMax_role_num(int max_role_num) {
		this.max_role_num = max_role_num;
	}
	public int getNow_role_num() {
		return now_role_num;
	}
	public void setNow_role_num(int now_role_num) {
		this.now_role_num = now_role_num;
	}
	public int getThumb_num() {
		return thumb_num;
	}
	public void setThumb_num(int thumb_num) {
		this.thumb_num = thumb_num;
	}
	
	@Override
	public String toString() {
		return "Story [story_id=" + story_id + ", story_name=" + story_name + ", story_setting=" + story_setting
				+ ", max_role_num=" + max_role_num + ", now_role_num=" + now_role_num + ", thumb_num=" + thumb_num
				+ "]";
	}

}
