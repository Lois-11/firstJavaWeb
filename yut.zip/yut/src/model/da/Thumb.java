package model.da;

public class Thumb {
	
	private int user_id;
	private int story_id;
	private int status;
	
	public Thumb(int story_id, int user_id, int status) {
		this.story_id = story_id;
		this.user_id = user_id;
		this.status = status;
	}
	
	public Thumb() {
		super();
	}

	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getStory_id() {
		return story_id;
	}
	public void setStory_id(int story_id) {
		this.story_id = story_id;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "Thumb [user_id=" + user_id + ", story_id=" + story_id + ", status=" + status + "]";
	}

}
