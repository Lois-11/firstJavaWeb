package model.da;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class User {
	private int user_id;
	private String password;
	private String username;
	private String gender;
	private String tel;
	private Date registDate;
	
	public User() {
		super();
	}
	public User(String username, String password, String gender, String tel, Date registDate) throws ParseException {
		this.username = username;
		this.password = password;
		this.gender = gender;
		this.tel = tel;
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String regDate = df.format(registDate);
		this.registDate = df.parse(regDate);
	}
	public int getID() {
		return user_id;
	}
	public void setID(int iD) {
		user_id = iD;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getRegistDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(this.registDate);
	}
	public void setRegistDate(Date registDate) throws ParseException {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String regDate = df.format(registDate);
		this.registDate = df.parse(regDate);
	}
	
	@Override
	public String toString() {
		return "User [ID=" + user_id + ", password=" + password + ", username=" + username + ", gender=" + gender + ", tel="
				+ tel + ", registDate=" + registDate + "]";
	}
	
}
