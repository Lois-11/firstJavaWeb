package model.da;

public class userCreRole {

	private int role_id;
	private int user_id;
	private int story_id;
	
	public userCreRole(int story_id, int user_id, int role_id) {
		this.story_id = story_id;
		this.user_id = user_id;
		this.role_id = role_id;
	}
	public userCreRole() {
		// TODO Auto-generated constructor stub
	}
	public int getRole_id() {
		return role_id;
	}
	public void setRole_id(int role_id) {
		this.role_id = role_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getStory_id() {
		return story_id;
	}
	public void setStory_id(int story_id) {
		this.story_id = story_id;
	}
	
	@Override
	public String toString() {
		return "userCreRole [role_id=" + role_id + ", user_id=" + user_id + ", story_id=" + story_id + "]";
	}
	
}
