package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.dao.userDao;
import utils.getReqParam;

/**
 * Servlet implementation class CancelServlet
 */
@WebServlet("/CancelServlet")
public class CancelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public CancelServlet() {
        super();
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Map<String, String> result = getReqParam.getParams(req);
		String tel = result.get("tel");
		res.setCharacterEncoding("UTF-8");
		res.setContentType("application/json; charset=utf-8");
		try {
			userDao.deleteUser(tel);
			String jsonStr = "{\"statuscode\":200}";
		    res.getWriter().write(jsonStr);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} finally {
		    if (res.getWriter() != null) {
		    	res.getWriter().close();
		    }
		}
//		req.getRequestDispatcher("success.jsp").forward(req, res);
	}

}
