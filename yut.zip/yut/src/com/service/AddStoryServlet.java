package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.dao.storyDao;
import utils.getReqParam;

/**
 * Servlet implementation class AddStoryServlet
 */
@WebServlet("/AddStoryServlet")
public class AddStoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AddStoryServlet() {
        super();
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Map<String, String> result = getReqParam.getParams(req);
		String story_name = result.get("styName");
		String tel = result.get("tel");
		String story_setting = result.get("stySetting");
		String[] roles = null;
		/**
		 * 14������ѡ��ɫ��
		 */
		try {
			storyDao.addStory(story_name, story_setting, 14, 0);
			String jsonStr = "{\"statuscode\":200}";
		    res.getWriter().write(jsonStr);
		    if (res.getWriter() != null) {
		    	res.getWriter().close();
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
