package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.dao.userDao;
import utils.getReqParam;

/**
 * Servlet implementation class UpdateTelServlet
 */
@WebServlet("/UpdateTelServlet")
public class UpdateTelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateTelServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Map<String, String> result = getReqParam.getParams(req);
		String new_tel = result.get("new_tel");
		String old_tel = result.get("now_tel");
		try {
			userDao.updateTel(new_tel, old_tel);
			res.setCharacterEncoding("UTF-8");
			res.setContentType("application/json; charset=utf-8");
			String jsonStr = "{\"statuscode\":200}";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
		    if (res.getWriter() != null) {
		    	res.getWriter().close();
		    }
		}
	}

}
