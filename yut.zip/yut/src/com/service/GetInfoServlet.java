package com.service;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.dao.userCreRoleDao;
import model.dao.userDao;
import utils.getReqParam;

/**
 * Servlet implementation class GetInfoServlet
 */
@WebServlet("/GetInfoServlet")
public class GetInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public GetInfoServlet() {
        super();
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Map<String, String> result = getReqParam.getParams(req);
		String tel = result.get("tel");
		res.setCharacterEncoding("UTF-8");
		res.setContentType("application/json; charset=utf-8");
		try {
			String nickname = userDao.queryUserName(tel);
			String gender = userDao.queryGender(tel);
			List<String> mystorys = userCreRoleDao.queryUserStory(tel);
			String jsonStr = "{nickname:\"";
		    jsonStr = jsonStr + nickname + "\", gender:\"";
		    jsonStr = jsonStr + gender + "\", tel:\"";
		    jsonStr = jsonStr + tel + "\", name:[\"";
		    for(int i=0; i<mystorys.size()-1; i++) {
		    	String str = mystorys.get(i);
		    	jsonStr = jsonStr + str + "\", \"";
		    }
		    jsonStr = jsonStr + mystorys.get(mystorys.size()-1) + "\"]}";
		    res.getWriter().write(jsonStr);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} finally {
		    if (res.getWriter() != null) {
		    	res.getWriter().close();
		    }
		}
	}

}
