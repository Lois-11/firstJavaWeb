package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.dao.userDao;
import utils.getReqParam;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
//		Map<String, String> result = getReqParam.getParams(req);
//		String tel = result.get("tel");
//		String password = result.get("password");
		String tel = req.getParameter("tel");
		String password = req.getParameter("password");
		boolean flag = userDao.checkUser(tel, password);
		if (flag) {
			res.setCharacterEncoding("UTF-8");
			res.setContentType("application/json; charset=utf-8");
			String jsonStr = "{\"statuscode\":200}";
			try {
			    res.getWriter().write(jsonStr);
			} catch (IOException e) {
			    e.printStackTrace();
			} finally {
			    if (res.getWriter() != null) {
			    	res.getWriter().close();
			    }
			}
			req.getRequestDispatcher("success.jsp").forward(req, res);
		}
		if(!flag)
			req.getRequestDispatcher("error.jsp").forward(req, res);
	}

}