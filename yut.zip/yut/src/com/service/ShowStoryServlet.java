package com.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import model.da.Story;
import model.dao.storyDao;
import utils.getReqParam;

/**
 * Servlet implementation class ShowStoryServlet
 */
@WebServlet("/ShowStoryServlet")
public class ShowStoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ShowStoryServlet() {
        super();
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Map<String, String> result = getReqParam.getParams(req);
		String[] storynames = null;
		List<Story> strList = null;
		try {
			strList = storyDao.query();
			int i = 0;
			for(Story str : strList) {
				storynames[i++] = str.getStory_name();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String jsonStr = "[{";
		for(int i=0;i<storynames.length-1;i++) {
			jsonStr += "name:\"" + storynames[i] + "\",";
		}
		jsonStr += "name:\"" + storynames[storynames.length-1] + "\"}]";
		res.getWriter().write(jsonStr);
		if (res.getWriter() != null) {
	    	res.getWriter().close();
	    }
	}

}
