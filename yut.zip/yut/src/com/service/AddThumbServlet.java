package com.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.dao.thumbDao;
import model.dao.userCreRoleDao;
import model.dao.userDao;
import utils.getReqParam;

/**
 * Servlet implementation class AddThumbServlet
 */
@WebServlet("/AddThumbServlet")
public class AddThumbServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddThumbServlet() {
        super();
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Map<String, String> result = getReqParam.getParams(req);
		String story_name = result.get("styName");
		String tel = result.get("tel");
		boolean isthumb = true;
		try {
			isthumb = thumbDao.isthumb(story_name, tel);
			if(!isthumb) {
				thumbDao.addThumb(story_name, tel);
				String jsonStr = "{\"statuscode\":200}";
			    res.getWriter().write(jsonStr);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
		    if (res.getWriter() != null) {
		    	res.getWriter().close();
		    }
		}
	}

}
