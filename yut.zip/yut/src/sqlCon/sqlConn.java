package sqlCon;

import java.sql.*;
import java.util.ResourceBundle;

public class sqlConn {

	public static final String URL = "jdbc:mysql://localhost/webwork?serverTimezone=UTC&useSSL=false";
	private static final String NAME = "Laiickes";
	private static final String PASSWORD = "Shuzhi9911";
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

	private static Connection conn = null;

	static {
		try {
			Class.forName(DRIVER);
			System.out.println("�ɹ�����MYSQL����");
		} catch (ClassNotFoundException e) {
			System.out.println("δ�ܳɹ������������������Ƿ�����������");
			e.printStackTrace();
		}
		try {
			conn = DriverManager.getConnection(URL, NAME, PASSWORD);
			System.out.println("��ȡ���ݿ����ӳɹ���");
		} catch (SQLException e) {
			System.out.println("��ȡ���ݿ�����ʧ�ܣ�");
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() {
		return conn;
	}
    
    /***
     * �ر����ݿ�ķ���
     * @param conn
     * @param ps
     * @param rs
     */
    public static void close(Connection conn,PreparedStatement ps,ResultSet rs){
        if(rs!=null){//�ر���Դ����������쳣
            try {
                rs.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        if(ps!=null){
            try {
                ps.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
    
    /***
     * ͬ����ɾ�ĵķ���
     * @param sql
     * @param arr
     * @return
     */
    public static boolean addUpdateDelete(String sql,Object[] arr) throws ClassNotFoundException{
        Connection con=null;
        PreparedStatement ps=null;
        try {
            con=sqlConn.getConnection();//��һ�� ���������ݿ�Ĳ���
            ps=con.prepareStatement(sql);//�ڶ�����Ԥ����
            //������������ֵ
            if(arr!=null && arr.length!=0){
                for(int i=0;i<arr.length;i++){
                    ps.setObject(i+1, arr[i]);
                }
            }
            int count=ps.executeUpdate();//���Ĳ���ִ��sql���
            if(count>0){
                return true;
            }else{
                return false;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }
    
    /*public static void main(String[] args) {
        try {
            sqlConn.getCon();
            System.out.println("�������ݿ����ӳɹ�");
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }*/
    
}